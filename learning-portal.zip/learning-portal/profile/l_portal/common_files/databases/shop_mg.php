
<?php

$db = new mysqli("localhost","root","","l_portal");

?>