<?php

    $header_information = "From:mohdgulm22@gmail.com \r\nMIME-Version:1.0 \r\ncontent-Type:text/html;charset=ISO-8859-1 \r\n";
    $message = "<html>
        <body style='background-color:red'>
        <h1>Thanks for choosing our website</h1>
        <h2>Yuor activation code is : 125445</h2>
        <h3>Don't share your activation code</h3>
        </body>
    </html>";
   if(mail("rshsheik@gmail.com","testing",$message,$header_information))
   {
       echo "success";
   }
   else{
       echo "not send";
   }
?>