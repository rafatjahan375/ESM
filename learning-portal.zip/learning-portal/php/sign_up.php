<?php
require("database.php");
$name = base64_decode($_POST['name']);
$number = base64_decode($_POST['number']);
$username = base64_decode($_POST['email']);
$password = base64_decode($_POST['password']);
$i;
$code = [];

for($i=0; $i<6; $i++)
{
   $code [] = rand(0,9);
}
$activation_code = implode($code);
$header_information = "From:arishasheikh1924@gmail.com \r\nMIME-Version:1.0 \r\ncontent-Type:text/html;charset=ISO-8859-1 \r\n";
  /* $header_information = "From:mohdgulm22@gmail.com \r\nMIME-Version:1.0 \r\nContent-Type:text/html;charset=ISO-8859-1 \r\n"; */
  $message = "<html>
  <body style='background:Blue;padding:50px'>
  <center>
  <h1>Thank You : <span style='color:white'>".$name."</span></h1>
  <h3>Thank For Choosing Our e-Learning Website </h3>
  <h3>Your Activation Code Is : <span style='color:white'>".$activation_code."</span></h3>
  <h3>Do'nt Share Your Activation Code !</span></h3>
  <h3>This is a website where we provide support and proper guideness through our web application.</span></h3>
  </center>
  </body>
  </html>";
$check_email = mail($username,"ESM LEARNING PORTAL",$message,$header_information);
if($check_email)
{
    $insert_data = "INSERT INTO users(full_name,username,password,number,activation_code) VALUES('$name','$username','$password','$number','$activation_code')";
    if($db -> query($insert_data))
    {
        echo "success";
    }
    else{
        echo "unable to insert";
    }
}
else{
    echo "unable to send activation code";
}
?>